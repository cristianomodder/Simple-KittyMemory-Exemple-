#include <pthread.h>
#include <jni.h>
#include "Memory/MemoryPatch.h"

#define Cristiano(offset) AgetAbsoluteAddress("libil2cpp.so",offset)

long AfindLibrary(const char *library) {
    char filename[0xFF] = {0},
    buffer[1024] = {0};
    FILE *fp = nullptr;
    long address = 0;

    sprintf(filename, "/proc/self/maps");

    fp = fopen( filename, "rt" );
    if( fp == nullptr ){
        perror("fopen");
        goto done;
    }

    while( fgets( buffer, sizeof(buffer), fp ) ) {
        if(strstr( buffer, library ) ){
            address = (long)strtoul( buffer, NULL, 16 );
            goto done;
        }
    }

    done:

    if(fp){
        fclose(fp);
    }
    return address;
}

long ClibBase;

long AgetAbsoluteAddress(const char* libraryName, long relativeAddr) {
    if (ClibBase == 0) {
        ClibBase = AfindLibrary(libraryName);
        if (ClibBase == 0) {
            ClibBase = 0;
        }
    }
    return ClibBase + relativeAddr;
}

void *CheckMemory(void *) {    
while (true) {      
if (Cristiano(0) != 0) {

MemoryPatch("libil2cpp.so", 0x000000, "\x00\x00\x00\x00", 4).Modify();

pthread_exit(nullptr);
}
sleep(1);
}
return nullptr;
}

extern "C"
void __attribute__ ((constructor)) Get_IsStart() {
    pthread_t ptid1;
    pthread_create(&ptid1, nullptr, CheckMemory, nullptr);

}
